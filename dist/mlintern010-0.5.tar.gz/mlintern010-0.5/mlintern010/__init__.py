from .main import About
from .main import EDA
from .main import Scaler
from .main import Plot