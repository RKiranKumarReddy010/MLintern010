from termcolor import colored
 
def inita():
    text = colored("This package made by:\nR KIRAN KUMAR REDDY\n22CSEAIML010\nGIETU (GUNPUR)", 'red', attrs=['reverse', 'blink'])
    print(text)