from termcolor import colored
class about: 
    def intern():
        text = colored("This package made by:\nR KIRAN KUMAR REDDY\n22CSEAIML010\nGIETU (GUNPUR)", 'red', attrs=['reverse', 'blink'])
        print(text)