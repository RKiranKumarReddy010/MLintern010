def inita():
    print("This package made by:\nR KIRAN KUMAR REDDY\n22CSEAIML010\n GIETU (GUNPUR)")
    