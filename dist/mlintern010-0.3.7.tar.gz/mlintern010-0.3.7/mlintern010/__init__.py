from .main import About
from .main import EDA
from .main import Scaler